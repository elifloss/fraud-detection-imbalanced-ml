from __future__ import annotations
from pathlib import Path
import json
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

from evaluate import compute_metrics

PROC = Path("data/processed")
REP = Path("reports")
REP.mkdir(parents=True, exist_ok=True)

def main():
    df = pd.read_csv(PROC / "clean.csv")
    if "Class" not in df.columns:
        raise ValueError("Expected target column named 'Class' (0=legit, 1=fraud).")

    X = df.drop(columns=["Class"])
    y = df["Class"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    models = {
        "logreg": LogisticRegression(max_iter=4000),
        "rf": RandomForestClassifier(n_estimators=300, n_jobs=-1, max_depth=12, random_state=42),
    }

    all_metrics = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        proba = model.predict_proba(X_test)[:, 1]
        pred = (proba >= 0.5).astype(int)
        all_metrics[name] = compute_metrics(y_test, pred, proba)

    out = REP / "baseline_metrics.json"
    out.write_text(json.dumps(all_metrics, indent=2))
    print(f"Saved: {out}")

    for name, m in all_metrics.items():
        print(f"{name}: ROC-AUC={m['roc_auc']:.4f} PR-AUC={m['pr_auc']:.4f}")

if __name__ == "__main__":
    main()
