from __future__ import annotations
from pathlib import Path
import pandas as pd

RAW = Path("data/raw")
PROC = Path("data/processed")
PROC.mkdir(parents=True, exist_ok=True)

def main():
    in_path = RAW / "creditcard.csv"
    if not in_path.exists():
        raise FileNotFoundError(
            "Missing data/raw/creditcard.csv. Download the Kaggle Credit Card Fraud dataset "
            "and place it at data/raw/creditcard.csv"
        )

    df = pd.read_csv(in_path)
    df = df.sample(frac=1.0, random_state=42).reset_index(drop=True)

    out_path = PROC / "clean.csv"
    df.to_csv(out_path, index=False)
    print(f"Saved: {out_path}  (rows={len(df)})")

if __name__ == "__main__":
    main()
