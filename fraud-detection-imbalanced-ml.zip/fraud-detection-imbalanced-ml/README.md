# Fraud Detection with Imbalanced Learning

Portfolio-ready starter kit for a **highly imbalanced classification** problem (credit card fraud).
Focus is on metrics that matter under imbalance: **PR-AUC, ROC-AUC, precision/recall**, and thresholding.

## Quickstart
1) Put the dataset in `data/raw/creditcard.csv` (common Kaggle filename).
2) Run:
```bash
pip install -r requirements.txt
python src/preprocess.py
python src/train_baseline.py
python src/train_imbalanced.py
```

## What This Shows Recruiters
- Handling real-world class imbalance
- Proper evaluation (PR curve, ROC curve)
- Clean ML pipeline code structure
- Explainability hooks (feature importance / SHAP-ready)
